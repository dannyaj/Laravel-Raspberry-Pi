<?php

namespace App\Kubernetes;

use App\Kubernetes\ApiServer;
use App\Kubernetes\Kubectl;

class Kubernetes{
    
    public function __construct($url){
        $this->api_server = new ApiServer($url);
        $this->kubectl = new Kubectl($url);
        $this->nodes = $this->get_node_list();
    }

    public function get_cpu_utilization(){
        $usages_list = [];
        foreach($this->nodes as $node){
            $usages_list[$node] = $this->api_server->metrics->get_cpu_usage_by_node($node);
        }
        return $this->parse_heapster($usages_list);
    }

    public function get_memory_utilization(){
        $usages_list = [];
        foreach($this->nodes as $node){
            $usages_list[$node] = $this->api_server->metrics->get_memory_usage_by_node($node);
        }
        return $this->parse_heapster($usages_list); 
    }

    public function get_node_list(){
        $output = [];
        foreach($this->api_server->get_nodes() as $node){
            $output[] = $node->metadata->name;
        }
        return $output;
    }

    public function get_node_summary(){
        $nodes = $this->kubectl->get_nodes();
        return $this->count_summary($nodes, 'status', 'Ready');
    }

    public function get_pod_summary(){
        $pods = $this->kubectl->get_pods();
        $this->pods = $pods;
        return $this->count_summary($pods, 'status', 'Running');
    }

    public function get_service_summary(){
        $services = $this->kubectl->get_services();
        return array('total' => count($services), 'rate' => 100);
    }

    public function get_top_node(){
        $output = [];
        $tops = $this->kubectl->get_top_node();
        foreach($tops as $top){
            $output[$top['name']] = $top;
        }

        ksort($output);

        return $output;
    }

    public function get_pods_allocation(){
        $output = [];
        $total = 0;
        foreach($this->pods as $pod){
            if(!array_key_exists($pod['node'], $output))
                $output[$pod['node']] = 0;
            $output[$pod['node']]++;
            $total++;
        }
        ksort($output);
        return $output;
    }

    private function count_summary($items, $key, $check){
        $ready_cnt = 0;

        foreach ($items as $item)
            if ($item[$key] == $check)
                $ready_cnt++;

        return array(
            'total' => count($items),
            'rate' => round($ready_cnt / count($items) * 100)
        );
    }

    private function parse_heapster($usages_list){
        $output = [];
        for ($index = 0; $index < 15; $index++){
            $value = 0;
            foreach($this->nodes as $node){
                $value += (int)$usages_list[$node][$index][1];
            }
            $output[] = array(
                $usages_list[$node][$index][0],
                $value
            );
        }
        return $output;
    }

}