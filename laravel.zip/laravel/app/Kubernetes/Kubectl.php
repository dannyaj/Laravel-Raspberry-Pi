<?php

namespace App\Kubernetes;

class Kubectl{

    public function __construct($url){
        $this->url = $url;
    }

    public function get_node_summary(){
        $nodes = $this->get_nodes();
        return $this->count_summary($nodes, 'status', 'Ready');
    }

    public function get_pod_summary(){
        $pods = $this->get_pods();
        return $this->count_summary($pods, 'status', 'Running');
    }

    public function get_service_summary(){
        $services = $this->get_services();
        return array('total' => count($services), 'rate' => 100);
    }

    public function get_nodes(){
        exec("/var/www/laravel/bin/kubectl --server $this->url get nodes", $res, $ret);
        return $this->parse_kubectl($res, $ret);

    }

    public function get_pods(){
        exec("/var/www/laravel/bin/kubectl --server $this->url get pods --all-namespaces -o wide", $res, $ret);
        return $this->parse_kubectl($res, $ret);

    }

    public function get_services(){
        exec("/var/www/laravel/bin/kubectl --server $this->url get services --all-namespaces", $res, $ret);
        return $this->parse_kubectl($res, $ret);
    }

    public function get_top_node(){
        exec("/var/www/laravel/bin/kubectl --server $this->url top node", $res, $ret);
        return $this->parse_kubectl($res, $ret);
    }

    private function parse_kubectl($data, $sys_code){
        if (count($data) < 2 || $sys_code != 0)
            return array();
        $headers = explode(" ", preg_replace('!\s+!', ' ', $data[0]));
        unset($data[0]);
        $output = [];
        foreach ($data as $string){
            $items = explode(" ", preg_replace('!\s+!', ' ', $string));
            $temp = [];
            foreach ($items as $idx => $item)
                $temp[strtolower($headers[$idx])] = $item;
            $output[] = $temp;
        }
        return $output;
    }

    private function count_summary($items, $key, $check){
        $ready_cnt = 0;

        foreach ($items as $item)
            if ($item[$key] == $check)
                $ready_cnt++;

        return array(
            'total' => count($items),
            'rate' => round($ready_cnt / count($items) * 100)
        );
    }
    
}