<?php

namespace App\Kubernetes;

use App\Kubernetes\ApiAbstract;
use App\Kubernetes\Metrics;

class ApiServer extends ApiAbstract{
    
    public $metrics;
    private $pods;

    public function __construct($url){
        parent::__construct($url);
        $this->metrics = new Metrics($url);
    }

    public function get_nodes(){
        return $this->get_child_items("/api/v1/nodes");
    }

    public function get_pods(){
        $this->pods = $this->get_child_items("/api/v1/pods");   
        return $this->pods;
    }

    public function get_services(){
        return $this->get_child_items("/api/v1/services");   
    }

    public function get_namespaces(){
        return $this->get_child_items("/api/v1/namespaces");
    }

    public function get_healthz(){
        return $this->get_child("/healthz");   
    }


}