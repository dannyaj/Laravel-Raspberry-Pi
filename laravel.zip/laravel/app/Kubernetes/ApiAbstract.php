<?php

namespace App\Kubernetes;

use App\RestClient\RestClient;

abstract class ApiAbstract extends RestClient{
    protected $url;
    protected $curl;
    protected $child_url_middle;
    public function __construct($url){
        $this->url = $url;
        $this->curl = $this->get($this->url);
    }

    protected function get_child_items($child_url){
        $response = $this->get_child($child_url);
        return (isset($response->items))? $response->items:null;
    }

    protected function get_child($child_url){
        $url = $this->url.$child_url;
        $curl = $this->get($url);
        return (isset($curl->response))? $curl->response:null;
    }

}