<?php

namespace App\Kubernetes;

use App\Kubernetes\ApiAbstract;

class Metrics extends ApiAbstract{

    public function __construct($url){
        parent::__construct($url."/api/v1/proxy/namespaces/kube-system/services/heapster/api/v1/model");
    }

    public function get_cpu_usage(){
        $curl = $this->get($this->url."/metrics/cpu/usage_rate");
        return (isset($curl->response->metrics))? $curl->response->metrics:array();
    }

    public function get_cpu_usage_with_timestamp(){
        $usages = $this->get_cpu_usage();
        return (count($usages) == 0)? $usages:$this->format_metrics_for_char_js($usages);
    }

    public function get_memory_usage(){
        $curl = $this->get($this->url."/metrics/memory/usage");
        return (isset($curl->response->metrics))? $curl->response->metrics:array();
    }

    public function get_memory_usage_with_timestamp(){
        $usages = $this->get_memory_usage();
        return (count($usages) == 0)? $usages:$this->format_metrics_for_char_js($usages);
    }

    public function get_cpu_usage_by_node($node_name){
        $curl = $this->get($this->url."/nodes/".$node_name."/metrics/cpu/usage_rate");
        return (isset($curl->response->metrics))? $this->format_metrics_for_char_js($curl->response->metrics):array();
    }

    public function get_memory_usage_by_node($node_name){
        $curl = $this->get($this->url."/nodes/".$node_name."/metrics/memory/usage");
        return (isset($curl->response->metrics))? $this->format_metrics_for_char_js($curl->response->metrics):array();
    }

    private function format_metrics_for_char_js($usages){
        $output = [];
        foreach($usages as $usage){
            $output[] = array(
                (strtotime($usage->timestamp) + 28800)."000", # UTC to CST 8 * 60 * 60
                $usage->value
            );
        }
        return $output;
    }
}