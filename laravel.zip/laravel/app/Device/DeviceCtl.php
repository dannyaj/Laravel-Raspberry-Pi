<?php

namespace App\Device;

use App\Kubernetes\Rest;

class DeviceCtl extends Rest{
    public function control($url, $body) {
        $curl = $this->post($url, $body);
        return $curl;
    }
}