<?php

namespace App\Device;

use DB;
use Config;
use App\RestClient\RestClient;

class Device{

    public function __construct(){ 
        $this->device_table = 'Device';
        $this->status_table = 'Monitor';
    }

    public function get_summary(){
        $count = 0;
        $devices = $this->get_list();   
        foreach($devices as $device) {
            if (array_key_exists('state', $device) && $device['state'] == 'new')
                $count++;
        }
        return array(
            'total' => count($devices),
            'new' => $count
        );
    }

    public function get_list(){
        return DB::collection($this->device_table)->get();
    }

    public function get_info_by_id($id){
        $devices = DB::collection($this->device_table)->where('id', $id)->get();
        return (count($devices) == 1)? $devices[0]:array();
    }

    public function get_status_by_id($id){
        return DB::collection($this->status_table)->where('id', $id)->orderBy('timestamp', 'desc')->take(1)->get();
    }

    public function get_last_status_by_id($id){
        $status = DB::collection($this->status_table)->where('id', $id)->orderBy('timestamp', 'desc')->take(1)->get();
        return (count($status) == 1)? $status[0]:array();
    }

    public function parse_status_by_id($id){
        $cpu_usage = [];
        $memory_usage = [];
        $disk_usage = [];
        $cpu_temp = [];
        $traffic_in = [];
        $traffic_out = [];
        $temp = [];
        $light = [];

        $status_list = $this->get_status_by_id($id);
        foreach($status_list as $status){
            $cpu_usage[] = array($status['timestamp'].'000', $status['cpu_usage']);
            $memory_usage[] = array($status['timestamp'].'000', $status['memory_usage']);
            $disk_usage[] = array($status['timestamp'].'000', $status['disk_usage']);
            $cpu_temp[] = array($status['timestamp'].'000', $status['cpu_temp']);
            $traffic_in[] = array($status['timestamp'].'000', $status['traffic']['bytes_recv']);
            $traffic_out[] = array($status['timestamp'].'000', $status['traffic']['bytes_sent']);
            $temp[] = array($status['timestamp'].'000', $status['temp']);
        }
        $output = array(
            'cpu_usage' => $cpu_usage,
            'memory_usage' => $memory_usage,
            'disk_usage' => $disk_usage,
            'cpu_temp' => $cpu_temp,
            'traffic_in' => $traffic_in,
            'traffic_out' => $traffic_out,
            'temp' => $temp,
            'light' => $light
        );
        return $output;
    }

    public function control_device($id, $token, $power) {
        $status = $this->get_last_status_by_id($id);
        $ip = $status['ip'];

        $rest = new RestClient();
        $curl = $rest->post(Config::get('apigateway.devicectl-url'), 
            array(
                "id" => $id,
                "url" => "http://".$ip.":3000/led",
                "power" => $power
            ), $token);
        return $curl->httpStatusCode;
    }

}