<?php

namespace App\RestClient;

use \Curl\Curl;

class RestClient{

    public function get($url){
        $curl = new Curl();
        $curl->get($url);
        return $curl;
    }

    public function post($url, $body, $token = null){        
        $curl = new Curl();        
        $curl->setHeader('Content-Type', 'application/json');   
        if ($token != null)
            $curl->setHeader('Auth-Token', $token);   
        $curl->post($url, json_encode($body));
        return $curl;
    }

    public function patch($url, $body){        
        $curl = new Curl();        
        $curl->patch($url, json_encode($body));   
        return $curl;
    }

    public function put($url, $body){        
        $curl = new Curl();        
        $curl->put($url, $body);        
        return $curl;
    }
    
    public function delete($url){        
        $curl = new Curl();        
        $curl->delete($url);        
        return $curl;
    }
}