<?php

namespace App\Auth;

use Config;
use App\RestClient\RestClient;

class Auth{

    public function get_token() {
        $username = "user";
        $password = "password";
        $rest = new RestClient();
        $curl = $rest->post(Config::get('authdata.server'), 
            array(
                "username" => Config::get('authdata.username'), 
                "password" => Config::get('authdata.password')
            ));
        return $curl->response;
    }

}