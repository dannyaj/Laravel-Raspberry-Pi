<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Config;

use App\Device\Device;
use App\Device\DeviceCtl;
use App\RestClient\RestClient;
use App\Auth\Auth;

class DeviceController extends Controller
{

    public function makeDeviceview($id){
        $device = new Device();
        return view('deviceview', array('device' => $device->get_info_by_id($id)));
    }

    public function makeDeviceStatus($id){
        $device = new Device();
        return $device->get_last_status_by_id($id);
    }
    
    public function setDeviceLed($id, $power){
        $device = new Device();
        $auth = new Auth();
        $token = $auth->get_token();
        return $device->control_device($id, $token, $power);
    }
}
