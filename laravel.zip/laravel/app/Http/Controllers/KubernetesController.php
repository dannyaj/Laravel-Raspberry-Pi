<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Config;

use App\Kubernetes\Kubernetes;
use App\Device\Device;

class KubernetesController extends Controller
{

    public function makeDashboard(){
        return view('dashboard');
    }

    public function makeDashboardResponse(){
        $url = Config::get('kubernetes.api-server');
        $k8s = new Kubernetes($url);
        $device = new Device();
        $from_time = strtotime("2017-04-02 10:21:00");
        $num = time() - abs($from_time);

        $response = array(
            "node" => $k8s->get_node_summary(),
            "pod" => $k8s->get_pod_summary(),
            "service" => $k8s->get_service_summary(),
            "device" => $device->get_summary(),
            "healthz" => $k8s->api_server->get_healthz(),
            "time" => array(
                "days" => $this->get_time_days($num),
                "others" => $this->get_time_others($num)
            ),
            "cpu_utlization" => $k8s->get_cpu_utilization(),
            "memory_utlization" => $k8s->get_memory_utilization(),
            "usage" => $k8s->get_top_node(),
            "pods_allocation" => $k8s->get_pods_allocation(),
            "device_list" => $device->get_list()
        );
        return $response;
    }

    private function get_time_days($num){
        $secs  = fmod($num, 60); $num = (int)($num / 60);
        $mins  = $num % 60;      $num = (int)($num / 60);
        $hours = $num % 24;      $num = (int)($num / 24);
        $days  = $num;
        return "$days days";
    }
    private function get_time_others($num){
        $secs  = fmod($num, 60); $num = (int)($num / 60);
        $mins  = $num % 60;      $num = (int)($num / 60);
        $hours = $num % 24;      $num = (int)($num / 24);
        $days  = $num;
        return "$hours hours $mins mins $secs secs";
    }    
}
