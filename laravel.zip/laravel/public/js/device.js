var a;
$(document).ready(function(){
    console.log('start')
    var id = $('small').text();
    dashboard.update('get', id+'/data', null);
    setInterval(function(){ dashboard.update('get', id+'/data', null) }, 1000);
    // $.plot( $("#chart_plot_cpu"), [ arr_data1 ],  chart_plot_01_settings );
    // $.plot( $("#chart_plot_memory"), [ arr_data1 ],  chart_plot_01_settings );

    a = jQuery("#Slider3").slider({ 
        from: 0, 
        to: 100, 
        scale: [0, '|', 25, '|', 50, '|', 75, '|', 100], 
        limits: false, 
        step: 1, 
        dimension: '&nbsp%', 
        skin: "round_plastic",
        callback: function(val){
            console.log(val)
            $.ajax({  
                type : 'GET',  
                url : '/devices/'+id+'/command/'+val,  
                headers : {  
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') 
                }
            })
        }
    });
    $('.jslider-value').css('top', '-30px')

})


var dashboard = {
    update: function (type, url, data){
        $.ajax({  
            type : 'GET',  
            url : url,  
            data : data,  
            headers : {  
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') 
            }
        }).done(function(data){
            console.log(data)
            usage.cpu_usage(data['cpu_usage'])
            usage.memory_usage(data['memory_usage'])
            usage.disk_usage(data['disk_usage'])
            usage.cpu_temp(data['cpu_temp'])
            usage.traffic_in(data['traffic']['bytes_recv'])
            usage.traffic_out(data['traffic']['bytes_sent'])
            usage.temp(data['temp'])
            usage.led(data['led'])
            jslider.update(data['led'])
        })
    }
}

var jslider = {
    last_power: 0,
    update: function(power){
        if (jslider.last_power != power){
            console.log('update')
            $('.jslider-value span').html(power)
            $('.jslider-value').css('left', power+'%')
            $('.jslider-pointer').css('left', power+'%')
            jslider.last_power = power;
        }
    }
}

var usage = {
    cpu_usage(usage){
        $('#cpu_usage').html('&nbsp&nbsp'+usage+'&nbsp%')
    },
    memory_usage(usage){
        $('#memory_usage').html('&nbsp&nbsp'+usage+'&nbsp%')
    },
    disk_usage(usage){
        $('#disk_usage').html('&nbsp&nbsp'+usage+'&nbsp%')
    },
    cpu_temp(temp){
        $('#cpu_temp').html('&nbsp&nbsp'+temp+'&nbspCelsius')
    },
    traffic_in(bytes){
        $('#traffic_in').html('&nbsp&nbsp'+bytes+'&nbspbytes')
    },
    traffic_out(bytes){
        $('#traffic_out').html('&nbsp&nbsp'+bytes+'&nbspbytes')
    },
    temp(temp){
        $('#temp').html('&nbsp&nbsp'+temp+'&nbspCelsius')
    },
    led(power){
        $('#led').html('&nbsp&nbsp'+power+'&nbsp%')
    }
}

var led = {
    set: function(){
        var id = $('small').text(),
            url = '/devices/'+id+'/command';
        $.ajax({  
            type : 'POST',  
            url : url,  
            data : [],  
            headers : {  
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') 
            }
        }).done(function(data){
            console.log(data)
        })
    }
}

var usagex = {
    percentage_formatter: function(y){
        return y + "%";
    },
    temp_formatter: function(y){
        return y + "Degree";
    },
    cpu_usage: function(used){
        var available = 100 - used;
        if (usage.cpu_usage_target == undefined)
            usage.cpu_usage_target = usage.draw('cpu_usage', usage.percentage_formatter, usage.format_data(available, used))
        else
            usage.update(usage.cpu_usage_target, usage.format_data(available, used))
    },
    memory_usage: function(used){
        var available = 100 - used;
        usage.draw('memory_usage', usage.percentage_formatter, usage.format_data(available, used))
    },
    disk_usage: function(used){
        var available = 100 - used;
        usage.draw('disk_usage', usage.percentage_formatter, usage.format_data(available, used))
    },
    cpu_temp: function(data){
        usage.draw('cpu_temp', usage.temp_formatter)
    },
    temp: function(data){
        usage.draw('temp', usage.temp_formatter)
    },
    led_control: function(data){
        usage.draw('led_controller', usage.percentage_formatter)
    },
    format_data: function(available, used){
        return [
                {label: 'Usaed', value: used},              
                {label: 'Available', value: available}
              ];
    },
    draw: function(target, formatter, data){
        console.log(data)
        if ($('#'+target).length ){

            return Morris.Donut({
              element: target,
              data: data,
              colors: ['#26B99A', '#DDDDDD'],
              formatter: formatter,
              resize: true
            });

        }
    },
    update: function(target, data){
        target.setData(data)
    }
}

var usagexx = {
    update: function(data){

        var formatter = function(val, axis){
            return val+" %"
        }
        var colors = ["rgba(26, 187, 156, 0.38)", "rgba(52, 125, 219, 0.38)", "rgba(255, 100, 100, 0.38)" ]
        var output = [
            {label: 'Disk', data: data['disk_usage']},
            {label: 'Memory', data: data['memory_usage']}, 
            {label: 'CPU', data: data['cpu_usage']}
        ]
        usage.draw('usage_chart', output, formatter, colors)
    },
    draw: function(target, data, formatter, colors){   
        console.log(data)
        var plot_settings = {
            series: {
                lines: {
                    show: true,
                    fill: true
                },
                splines: {
                    show: true,
                    tension: 0.4,
                    lineWidth: 1,
                    fill: 0.1
                },
                points: {
                    radius: 1,
                    show: true
                },
                shadowSize: 0
            },
            grid: {
                verticalLines: true,
                hoverable: true,
                clickable: true,
                tickColor: "#d5d5d5",
                borderWidth: 1,
                color: '#fff'
            },
            colors: colors,
            // colors: ["rgba(26, 187, 156, 0.38)", "rgba(52, 125, 219, 0.38)", "rgba(255, 100, 100, 0.38)" ],
            // colors: ["rgba(38, 185, 154, 0.38)", "rgba(3, 88, 106, 0.38)", "rgba(6, 176, 212, 0.38)"],
            xaxis: {
                tickColor: "rgba(51, 51, 51, 0.06)",
                mode: "time",
                tickLength: 10,
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 10
            },
            yaxis: {
                tickColor: "rgba(51, 51, 51, 0.06)",
                tickFormatter: formatter
            },
            legend: {
                noColumns: 0,
                position: "ne",
                labelBoxBorderColor: "rgba(0, 0, 0, 1)"
            }
        }
        $.plot( $("#"+target), data,  plot_settings );
    }
}