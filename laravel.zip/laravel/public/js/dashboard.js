$(document).ready(function(){
    console.log('start')
    dashboard.update('get', '/dashboard/data', null);
    // setInterval(function(){ dashboard.update('get', '/dashboard/data', null) }, 1000);
})

var k8s = {
    update: function(){
        // send_ajax
    }
}

var cards = {
    server: function(server){
        cards.update('#total-server', server)
    },
    service: function(service){
        cards.update('#total-service', service)
    },
    pod: function(pod){
        cards.update('#total-pod', pod)
    },
    device: function(device){
        var main = $('#total-device'),
            count = main.find('.count'),
            status = main.find('.count_bottom');
        count.text(device.total)
        if (device.new == 0)
            status.html('<i class="green"><i class="fa fa-check"></i>0</i> new device')      
        else
            status.html('<i class="green"><i class="fa fa-bell"></i>'+device.new+' </i> new device')      
    },
    uptime: function(time){
        var main = $('#uptime'),
            day = main.find('.count'),
            others = main.find('.count_bottom');
        day.text(time.days);
        others.html(time.others);
    },
    health: function(string){
        var main = $('#health'),
            count = main.find('.count'),
            status = main.find('.count_bottom');
        count.text(string)
        status.html('<i class="green"><i class="fa fa-check"></i> </i>Cluster Running')
    },
    update: function(target, data){
        var main = $(target),
            count = main.find('.count'),
            status = main.find('.count_bottom');
        count.text(data.total)
        if (data.rate == 100)
            status.html('<i class="green"><i class="fa fa-check"></i> 100% </i> Running')
        else
            status.html('<i class="green"><i class="fa fa-exclamation-triangle"></i> '+data.rate+'% </i> Running')
    }   
}



var dashboard = {
    update: function (type, url, data){
        $.ajax({  
            type : 'GET',  
            url : url,  
            data : data,  
            headers : {  
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') 
            }
        }).done(function(data){
            console.log(data)
            cards.server(data.node)
            cards.service(data.service)
            cards.pod(data.pod)
            cards.device(data.device)
            cards.uptime(data.time)
            cards.health(data.healthz)
            utlization.cpu(data.cpu_utlization)
            utlization.memory(data.memory_utlization)
            usage.update(data.usage)
            allocation.update(data.pods_allocation)
            devices_table.update(data.device_list)
        })
    }
}

var utlization = {
    cpu: function(data){
        var formatter = function(val, axis){
            return (val / 1000).toFixed(2)+" Cores"
        }        
        utlization.draw('chart_plot_cpu', data, formatter)
    },
    memory: function(data){
        var formatter = function(val, axis) {
            return (val / 1024 / 1024 / 1024).toFixed(2)+" GB"
        }
        utlization.draw('chart_plot_memory', data, formatter)
    },
    draw: function(target, data, formatter){
        var plot_settings = {
            series: {
                lines: {
                    show: true,
                    fill: true
                },
                splines: {
                    show: true,
                    tension: 0.4,
                    lineWidth: 1,
                    fill: 0.4
                },
                points: {
                    radius: 1,
                    show: true
                },
                shadowSize: 0
            },
            grid: {
                verticalLines: true,
                hoverable: true,
                clickable: true,
                tickColor: "#d5d5d5",
                borderWidth: 1,
                color: '#fff'
            },
            colors: ["rgba(38, 185, 154, 0.38)", "rgba(3, 88, 106, 0.38)"],
            xaxis: {
                tickColor: "rgba(51, 51, 51, 0.06)",
                mode: "time",
                tickLength: 10,
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 10
            },
            yaxis: {
                tickColor: "rgba(51, 51, 51, 0.06)",
                tickFormatter: formatter
            }
        }
        $.plot( $("#"+target), [ data ],  plot_settings );
    }
}

var usage = {
    update: function(usage_data){
        // console.log(usage.get_template())
        
        $.each(usage_data, function(idx, data){
            // console.log(data)
            var cpu_id = data['name']+'_cpu',
                mem_id = data['name']+'_mem',
                cpu_target = $('#'+cpu_id),
                mem_target = $('#'+mem_id)
            if (cpu_target.length == 0){
                $('#cpu_usage').append(usage.get_template(cpu_id, data['name']))
                cpu_target = $('#'+cpu_id)
            }
            cpu_target.find('.progress-bar')
                .attr('aria-valuenow', data['cpu%'])
                .css('width', data['cpu%'])
            cpu_target.find('.w_10 span').text(data['cpu%'])

            if (mem_target.length == 0){
                $('#memory_usage').append(usage.get_template(mem_id, data['name']))
                mem_target = $('#'+mem_id)                
            }
            mem_target.find('.progress-bar')
                .attr('aria-valuenow', data['memory%'])
                .css('width', data['memory%'])
            mem_target.find('.w_10 span').text(data['memory%'])
        })
    },
    get_template: function(node_id, node_name, percentage ){
        return '<div class="widget_summary" id='+node_id+'>'+
                    '<div class="w_left w_40">'+
                      '<span>'+node_name+'</span>'+
                    '</div><span>&nbsp&nbsp</span>'+
                    '<div class="w_center w_50">'+
                      '<div class="progress">'+
                        '<div class="progress-bar bg-green" role="progressbar" aria-valuenow="0%" aria-valuemin="0" aria-valuemax="100" style="width: 0%;">'+
                          '<span class="sr-only">0% Used</span>'+
                        '</div>'+
                      '</div>'+
                    '</div><span>&nbsp</span>'+                    
                    '<div class="w_left w_10">'+
                      '<span>0%</span>'+
                    '</div>'+
                    '<div class="clearfix"></div>'+
                  '</div>'
    }  
}

var allocation = {
    colors: function(){
        return ['blue',  'purple', 'green', 'aero', 'red', 'dark', 'new_color1', 'new_color2', 'new_color3']
    },
    update: function(data){
        var chart_data = [],
            chart_labels = [],
            table = $('#pod_allocation table table'),
            idx = 0,
            colors = allocation.colors();
        table.html('')
        $.each(data, function(node_name, count){
            chart_data.push(count);
            chart_labels.push(node_name)
            table.append(allocation.table_template(node_name, colors[idx++], count))
        })
        allocation.draw(chart_labels, chart_data)
    },
    draw: function(labels, data){
        if (allocation.chart == undefined){
            var chart_doughnut_settings = {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: [
                            "#3498DB",
                            "#9B59B6",
                            "#1ABB9C",
                            "#8CC2CB",
                            "#E74C3C",
                            "#34495E",
                            "#FFD700",
                            "#AF4570",
                            "#207B6E"
                        ]
                    }]
                },
                options: {
                    responsive: false,
                    legend: {
                        display: false,
                        position: 'top'
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
         
            }
            allocation.chart = new Chart( $('#pods_allocation'), chart_doughnut_settings)
        } else {
            allocation.chart.data.datasets[0].data = data

        }
    },
    chart: null,
    table_template: function(name, color, data){
      return '<tr>'+
        '<td>'+
          '<p><i class="fa fa-square '+color+'"></i>'+name+' </p>'+
        '</td>'+
        '<td>'+data+'</td>'+
      '</tr>'
    }
}

var devices_table = {
    update: function(devices){
        var table = $('#device_list table tbody')
        // .html('')
        $.each(devices, function(idx, device){
            var device_tr = $('#'+device['id'])
            if (device_tr.length == 0){
                table.append(devices_table.get_template(device['id'], idx+1, device['name'], device['ip'], device['state']))
            } else {
                var td = table.find('td')
                td.eq(0).text(device['name'])
                td.eq(1).text(device['ip'])
                td.eq(2).text(device['state'])
            }
        })
    }, 
    get_template: function(id, idx, name, ip, type){
        return '<tr id="'+id+'">'+
                    '<th scope="row">'+idx+'</th>'+
                    '<td>'+name+'</td>'+
                    '<td>'+ip+'</td>'+
                    '<td>'+type+'</td>'+
                    '<td style=" display: inherit;">'+
                        '<ul class="nav navbar-right panel_toolbox" style="min-width: auto;">'+
                            '<li class="dropdown">'+
                                '<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>'+
                                '<ul class="dropdown-menu" role="menu">'+
                                    '<li><a href="/devices/'+id+'">View Detail</a></li>'+
                                '</ul>'+
                            '</li>'+
                        '</ul>'+
                    '</td>'+
                '</tr>'
    }
}
