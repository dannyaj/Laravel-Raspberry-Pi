<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Device Overview</title>

    <!-- Bootstrap -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="/css/nprogress.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="/css/custom.min.css" rel="stylesheet">
    <link href="/css/device.css" rel="stylesheet">

    <link rel="stylesheet" href="/css/jslider.css" type="text/css">
    <link rel="stylesheet" href="/css/jslider.blue.css" type="text/css">
    <link rel="stylesheet" href="/css/jslider.plastic.css" type="text/css">
    <link rel="stylesheet" href="/css/jslider.round.css" type="text/css">
    <link rel="stylesheet" href="/css/jslider.round.plastic.css" type="text/css">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.html" class="site_title"><i class="fa fa-paw"></i> <span>Gentelella Alela!</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="/dashboard">Dashboard</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-desktop"></i> Devices <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="/devices">Devices List</a></li>
                    </ul>
                  </li>
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    John Doe
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="javascript:;"> Profile</a></li>
                    <li>
                      <a href="javascript:;">
                        <span class="badge bg-red pull-right">50%</span>
                        <span>Settings</span>
                      </a>
                    </li>
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="login.html"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div>
            <div class="page-title">
              <div class="title_left">
                <h3>Device Overview - <small><?php echo e($device['id']); ?></small></h3>
              </div>
            </div>
            
            <div class="clearfix"></div>

             <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="x_panel"  style="height: 360px;">
                  <div class="x_title">
                    <h2>Information</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <table class="table" style="margin-bottom: 0px">
                        <tr><th>Name </th><td>&nbsp&nbsp
                            <?php  echo (array_key_exists("name", $device))? $device['name']:"N/A"; ?>    
                        </td></tr>
                        <tr><th>Asset State </th><td>&nbsp&nbsp
                            <?php  echo (array_key_exists("state", $device))? $device['state']:"N/A"; ?> 
                        </td></tr>  
                        <tr><th>IP </th><td>&nbsp&nbsp
                            <?php  echo (array_key_exists("ip", $device))? $device['ip']:"N/A"; ?> 
                        </td></tr>
                        <tr><th>CPU Model</th><td>&nbsp&nbsp
                            <?php  echo (array_key_exists("cpu_model", $device))? $device['cpu_model']:"N/A"; ?> 
                        </td></tr>
                        <tr><th>Memory Size</th><td>&nbsp&nbsp
                            <?php  echo (array_key_exists("memory_size", $device))? $device['memory_size']:"N/A"; ?> 
                        </td></tr>
                        <tr><th>Disk Size</th><td>&nbsp&nbsp
                            <?php  echo (array_key_exists("disk_size", $device))? $device['disk_size']:"N/A"; ?> 
                        </td></tr>
                        <tr><th>Sensor Type</th><td>&nbsp&nbsp
                            <?php  echo (array_key_exists("sensor_type", $device))? $device['sensor_type']:"N/A"; ?> 
                        </td></tr>
                        <tr><th>Addon</th><td>&nbsp&nbsp
                            <?php  echo (array_key_exists("additional", $device))? $device['additional']:"N/A"; ?> 
                        </td></tr>
                    </table>

                  </div>
                </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="x_panel"  style="height: 360px;">
                  <div class="x_title">
                    <h2>Monitoring</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <table class="table" style="margin-bottom: 0px">
                        <tr><th>CPU Usage</th><td id="cpu_usage"></td></tr>
                        <tr><th>Memory Usage</th><td id="memory_usage"></td></tr>  
                        <tr><th>Disk Usage</th><td id="disk_usage"></td></tr>
                        <tr><th>CPU Temperature</th><td id="cpu_temp"></td></tr>
                        <tr><th>Traffic In</th><td id="traffic_in"></td></tr>
                        <tr><th>Traffic Out</th><td id="traffic_out"></td></tr>
                        <tr><th>Addon Temperature</th><td id="temp"></td></tr>
                        <tr><th>Addon LED Power</th><td id="led"></td></tr>
                    </table>
                  </div>
                </div>
              </div>

            </div>
            <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="x_panel"  style="height: 360px;">
                  <div class="x_title">
                    <h2>Control LED Power</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="layout-slider" style="margin-top: 10px">
                      <input id="Slider3" type="slider" name="area" value="0" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
    <!-- jQuery -->
    <script src="/js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="/js/fastclick.js"></script>
    <!-- NProgress -->
    <script src="/js/nprogress.js"></script>
    <!-- morris.js -->
    <script src="/js/raphael.min.js"></script>
    <script src="/js/morris.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="/js/custom.js"></script>
    
    <script src="/js/device.js"></script>


    <script src="/js/jshashtable-2.1_src.js"></script>
    <script src="/js/jquery.numberformatter-1.2.3.js"></script>
    <script src="/js/tmpl.js"></script>
    <script src="/js/jquery.dependClass-0.1.js"></script>
    <script src="/js/draggable-0.1.js"></script>
    <script src="/js/jquery.slider.js"></script>

  </body>
</html>
