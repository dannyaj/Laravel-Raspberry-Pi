<?php

return [
    'server' => 'http://10.1.5.130:32136/auth',
    'username' => 'user',
    'password' => 'password'
];