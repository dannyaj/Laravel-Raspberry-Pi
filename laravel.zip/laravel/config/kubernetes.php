<?php

return [
    'api-server' => '10.1.5.126:8080'
    // 'api-server' => '10.1.5.126:8080'
];