<?php

return [
    'devicectl-url' => 'http://10.1.5.130:30619/v1/devicectl/control'
];